
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.barrycat.drawer.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.barrycat.drawer.item.ScrewItem;
import net.barrycat.drawer.DrawerMod;

public class DrawerModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, DrawerMod.MODID);
	public static final RegistryObject<Item> OAK_DRAWER = block(DrawerModBlocks.OAK_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> SPRUCE_DRAWER = block(DrawerModBlocks.SPRUCE_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> BIRCH_DRAWER = block(DrawerModBlocks.BIRCH_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> JUNGLE_DRAWER = block(DrawerModBlocks.JUNGLE_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> ACACIA_DRAWER = block(DrawerModBlocks.ACACIA_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> DARK_OAK_DRAWER = block(DrawerModBlocks.DARK_OAK_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> MANGROVE_DRAWER = block(DrawerModBlocks.MANGROVE_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> CRIMSON_DRAWER = block(DrawerModBlocks.CRIMSON_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> WARPED_DRAWER = block(DrawerModBlocks.WARPED_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> SCREW = REGISTRY.register("screw", () -> new ScrewItem());
	public static final RegistryObject<Item> STRIPPED_OAK_DRAWER = block(DrawerModBlocks.STRIPPED_OAK_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_SPRUCE_DRAWER = block(DrawerModBlocks.STRIPPED_SPRUCE_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_BIRCH_DRAWER = block(DrawerModBlocks.STRIPPED_BIRCH_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_JUNGLE_DRAWER = block(DrawerModBlocks.STRIPPED_JUNGLE_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_ACACIA_DRAWER = block(DrawerModBlocks.STRIPPED_ACACIA_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_DARK_OAK_DRAWER = block(DrawerModBlocks.STRIPPED_DARK_OAK_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_MANGROVE_DRAWER = block(DrawerModBlocks.STRIPPED_MANGROVE_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_CRIMSON_DRAWER = block(DrawerModBlocks.STRIPPED_CRIMSON_DRAWER, DrawerModTabs.TAB_DRAWER);
	public static final RegistryObject<Item> STRIPPED_WARPED_DRAWER = block(DrawerModBlocks.STRIPPED_WARPED_DRAWER, DrawerModTabs.TAB_DRAWER);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
