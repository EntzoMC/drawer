
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.barrycat.drawer.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class DrawerModTabs {
	public static CreativeModeTab TAB_DRAWER;

	public static void load() {
		TAB_DRAWER = new CreativeModeTab("tabdrawer") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(DrawerModBlocks.OAK_DRAWER.get());
			}

			@Override
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
}
