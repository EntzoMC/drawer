
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.barrycat.drawer.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.barrycat.drawer.DrawerMod;

public class DrawerModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DrawerMod.MODID);
	public static final RegistryObject<SoundEvent> DRAWER_OPEN = REGISTRY.register("drawer_open",
			() -> new SoundEvent(new ResourceLocation("drawer", "drawer_open")));
	public static final RegistryObject<SoundEvent> DRAWER_CLOSE = REGISTRY.register("drawer_close",
			() -> new SoundEvent(new ResourceLocation("drawer", "drawer_close")));
}
