
package net.barrycat.drawer.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

import net.barrycat.drawer.init.DrawerModTabs;

public class ScrewItem extends Item {
	public ScrewItem() {
		super(new Item.Properties().tab(DrawerModTabs.TAB_DRAWER).stacksTo(64).rarity(Rarity.COMMON));
	}
}
