
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.entzomc.drawer.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class DrawerModTabs {
	public static CreativeModeTab TAB_DRAWER;

	public static void load() {
		TAB_DRAWER = FabricItemGroupBuilder.create(new ResourceLocation("drawer", "drawer")).icon(() -> new ItemStack(DrawerModBlocks.OAK_DRAWER)).build();
	}
}
