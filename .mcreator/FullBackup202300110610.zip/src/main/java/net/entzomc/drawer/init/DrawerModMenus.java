
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.entzomc.drawer.init;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;

import net.entzomc.drawer.world.inventory.WarpedDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedWarpedDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedSpruceDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedOakDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedMangroveDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedJungleDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedDarkOakDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedCrimsonDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedBirchDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.StrippedAcaciaDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.SpruceDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.OakDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.MangroveDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.JungleDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.DarkOakDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.CrimsonDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.BirchDrawerGuiMenu;
import net.entzomc.drawer.world.inventory.AcaciaDrawerGuiMenu;
import net.entzomc.drawer.client.gui.WarpedDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedWarpedDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedSpruceDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedOakDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedMangroveDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedJungleDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedDarkOakDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedCrimsonDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedBirchDrawerGuiScreen;
import net.entzomc.drawer.client.gui.StrippedAcaciaDrawerGuiScreen;
import net.entzomc.drawer.client.gui.SpruceDrawerGuiScreen;
import net.entzomc.drawer.client.gui.OakDrawerGuiScreen;
import net.entzomc.drawer.client.gui.MangroveDrawerGuiScreen;
import net.entzomc.drawer.client.gui.JungleDrawerGuiScreen;
import net.entzomc.drawer.client.gui.DarkOakDrawerGuiScreen;
import net.entzomc.drawer.client.gui.CrimsonDrawerGuiScreen;
import net.entzomc.drawer.client.gui.BirchDrawerGuiScreen;
import net.entzomc.drawer.client.gui.AcaciaDrawerGuiScreen;
import net.entzomc.drawer.DrawerMod;

public class DrawerModMenus {
	public static MenuType<OakDrawerGuiMenu> OAK_DRAWER_GUI;
	public static MenuType<SpruceDrawerGuiMenu> SPRUCE_DRAWER_GUI;
	public static MenuType<BirchDrawerGuiMenu> BIRCH_DRAWER_GUI;
	public static MenuType<JungleDrawerGuiMenu> JUNGLE_DRAWER_GUI;
	public static MenuType<AcaciaDrawerGuiMenu> ACACIA_DRAWER_GUI;
	public static MenuType<DarkOakDrawerGuiMenu> DARK_OAK_DRAWER_GUI;
	public static MenuType<MangroveDrawerGuiMenu> MANGROVE_DRAWER_GUI;
	public static MenuType<CrimsonDrawerGuiMenu> CRIMSON_DRAWER_GUI;
	public static MenuType<WarpedDrawerGuiMenu> WARPED_DRAWER_GUI;
	public static MenuType<StrippedOakDrawerGuiMenu> STRIPPED_OAK_DRAWER_GUI;
	public static MenuType<StrippedSpruceDrawerGuiMenu> STRIPPED_SPRUCE_DRAWER_GUI;
	public static MenuType<StrippedBirchDrawerGuiMenu> STRIPPED_BIRCH_DRAWER_GUI;
	public static MenuType<StrippedJungleDrawerGuiMenu> STRIPPED_JUNGLE_DRAWER_GUI;
	public static MenuType<StrippedAcaciaDrawerGuiMenu> STRIPPED_ACACIA_DRAWER_GUI;
	public static MenuType<StrippedDarkOakDrawerGuiMenu> STRIPPED_DARK_OAK_DRAWER_GUI;
	public static MenuType<StrippedMangroveDrawerGuiMenu> STRIPPED_MANGROVE_DRAWER_GUI;
	public static MenuType<StrippedCrimsonDrawerGuiMenu> STRIPPED_CRIMSON_DRAWER_GUI;
	public static MenuType<StrippedWarpedDrawerGuiMenu> STRIPPED_WARPED_DRAWER_GUI;

	public static void load() {
		OAK_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "oak_drawer_gui"), new ExtendedScreenHandlerType<>(OakDrawerGuiMenu::new));
		OakDrawerGuiScreen.screenInit();
		SPRUCE_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "spruce_drawer_gui"), new ExtendedScreenHandlerType<>(SpruceDrawerGuiMenu::new));
		SpruceDrawerGuiScreen.screenInit();
		BIRCH_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "birch_drawer_gui"), new ExtendedScreenHandlerType<>(BirchDrawerGuiMenu::new));
		BirchDrawerGuiScreen.screenInit();
		JUNGLE_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "jungle_drawer_gui"), new ExtendedScreenHandlerType<>(JungleDrawerGuiMenu::new));
		JungleDrawerGuiScreen.screenInit();
		ACACIA_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "acacia_drawer_gui"), new ExtendedScreenHandlerType<>(AcaciaDrawerGuiMenu::new));
		AcaciaDrawerGuiScreen.screenInit();
		DARK_OAK_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "dark_oak_drawer_gui"), new ExtendedScreenHandlerType<>(DarkOakDrawerGuiMenu::new));
		DarkOakDrawerGuiScreen.screenInit();
		MANGROVE_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "mangrove_drawer_gui"), new ExtendedScreenHandlerType<>(MangroveDrawerGuiMenu::new));
		MangroveDrawerGuiScreen.screenInit();
		CRIMSON_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "crimson_drawer_gui"), new ExtendedScreenHandlerType<>(CrimsonDrawerGuiMenu::new));
		CrimsonDrawerGuiScreen.screenInit();
		WARPED_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "warped_drawer_gui"), new ExtendedScreenHandlerType<>(WarpedDrawerGuiMenu::new));
		WarpedDrawerGuiScreen.screenInit();
		STRIPPED_OAK_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_oak_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedOakDrawerGuiMenu::new));
		StrippedOakDrawerGuiScreen.screenInit();
		STRIPPED_SPRUCE_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_spruce_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedSpruceDrawerGuiMenu::new));
		StrippedSpruceDrawerGuiScreen.screenInit();
		STRIPPED_BIRCH_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_birch_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedBirchDrawerGuiMenu::new));
		StrippedBirchDrawerGuiScreen.screenInit();
		STRIPPED_JUNGLE_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_jungle_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedJungleDrawerGuiMenu::new));
		StrippedJungleDrawerGuiScreen.screenInit();
		STRIPPED_ACACIA_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_acacia_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedAcaciaDrawerGuiMenu::new));
		StrippedAcaciaDrawerGuiScreen.screenInit();
		STRIPPED_DARK_OAK_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_dark_oak_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedDarkOakDrawerGuiMenu::new));
		StrippedDarkOakDrawerGuiScreen.screenInit();
		STRIPPED_MANGROVE_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_mangrove_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedMangroveDrawerGuiMenu::new));
		StrippedMangroveDrawerGuiScreen.screenInit();
		STRIPPED_CRIMSON_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_crimson_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedCrimsonDrawerGuiMenu::new));
		StrippedCrimsonDrawerGuiScreen.screenInit();
		STRIPPED_WARPED_DRAWER_GUI = Registry.register(Registry.MENU, new ResourceLocation(DrawerMod.MODID, "stripped_warped_drawer_gui"), new ExtendedScreenHandlerType<>(StrippedWarpedDrawerGuiMenu::new));
		StrippedWarpedDrawerGuiScreen.screenInit();
	}
}
