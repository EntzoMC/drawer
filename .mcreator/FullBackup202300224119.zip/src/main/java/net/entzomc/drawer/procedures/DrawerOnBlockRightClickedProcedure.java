package net.entzomc.drawer.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.BlockPos;

import net.entzomc.drawer.init.DrawerModSounds;
import net.entzomc.drawer.DrawerMod;

import java.util.Map;

public class DrawerOnBlockRightClickedProcedure {

	public static void execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				DrawerMod.LOGGER.warn("Failed to load dependency world for procedure DrawerOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				DrawerMod.LOGGER.warn("Failed to load dependency x for procedure DrawerOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				DrawerMod.LOGGER.warn("Failed to load dependency y for procedure DrawerOnBlockRightClicked!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				DrawerMod.LOGGER.warn("Failed to load dependency z for procedure DrawerOnBlockRightClicked!");
			return;
		}
		LevelAccessor world = (LevelAccessor) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, new BlockPos(x, y, z), DrawerModSounds.DRAWER_OPEN, SoundSource.NEUTRAL, 1, 1);
			} else {
				_level.playLocalSound(x, y, z, DrawerModSounds.DRAWER_OPEN, SoundSource.NEUTRAL, 1, 1, false);
			}
		}
	}
}
